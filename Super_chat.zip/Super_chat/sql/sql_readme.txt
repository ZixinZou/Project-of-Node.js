3 tables��user, list and reply.

"forum.sql" is all the document in a single file

The files in "sql_separate" is separate database tables.

Two kinds of file you can choose. 